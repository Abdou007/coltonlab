
This release (V6.10a) includes the new HASP driver installation required on some new motherboards.